<?php exit;?>{
    "1": {
        "name": "ravi@novopay.in",
        "path": "admin",
        "password": "81dc9bdb52d04dc20036dbd8313ed055",
        "userID": "1",
        "role": "1",
        "config": {
            "sizeMax": 0,
            "sizeUse": 1024
        },
        "groupInfo": {
            "1": "write"
        },
        "createTime": 1565351013,
        "status": 1,
        "lastLogin": 1595845458,
        "nickName": "Ravi Kumar",
        "sizeMax": "0"
    }
}