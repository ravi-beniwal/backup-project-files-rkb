<?php exit;?>{
    "1": {
        "name": "ravi",
        "path": "admin",
        "password": "e32d32a710baea1f03c20230ef8c9c06",
        "userID": "1",
        "role": "1",
        "config": {
            "sizeMax": 0,
            "sizeUse": 1024
        },
        "groupInfo": {
            "1": "write"
        },
        "createTime": 1565351013,
        "status": 1,
        "lastLogin": 1575441766,
        "nickName": "Ravi Kumar",
        "sizeMax": "0"
    }
}